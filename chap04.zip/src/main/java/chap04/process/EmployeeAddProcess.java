package chap04.process;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import chap04.database.DBConnector;
import chap04.model.Employee;

@WebServlet("/chap04/WEB-INF/views/add")
public class EmployeeAddProcess extends HttpServlet implements Process{
	Integer employee_id;
	String frist_name;
	String last_name;
	String email;
	String hire_date;
	String job_id;
	String phone_number;
	Integer salary;
	
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
			throws ServletException, IOException {
		employee_id = Integer.parseInt(req.getParameter("employee_id"));
		frist_name = req.getParameter("frist_name");
		last_name = req.getParameter("last_name");
		email = req.getParameter("email");
		hire_date = req.getParameter("hire_date");
		job_id = req.getParameter("job_id");
		phone_number = req.getParameter("Phone_number");
		salary = Integer.parseInt(req.getParameter("salary"));
		
		
	}

	@Override
	public String process(HttpServletRequest request, HttpServletResponse response) {
		String sql = "insert into employees(employee_id,first_name,last_name,email,hire_date,job_id,phone_number,salary)"
				+ "values(?,?,?,?,?,?,?,?)";
		
		try(
				Connection conn = DBConnector.getConnction();
				PreparedStatement pstmt = conn.prepareStatement(sql);
				
						){
						pstmt.setInt(1, employee_id);//id
						pstmt.setString(2, frist_name);//first name
						pstmt.setString(3, last_name);// last name
						pstmt.setString(4, email);// email
						pstmt.setString(5, hire_date);// hire date
						pstmt.setString(6, job_id);// job id
						pstmt.setString(7, phone_number);// phone_number
						pstmt.setInt(8, salary);//salary
							
							
						}
						
				 	catch (SQLException e) {
					e.printStackTrace();
				}
		
		return "/WEB-INF/views/employee/list.jsp";		
	}

}
