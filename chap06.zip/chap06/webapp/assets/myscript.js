const btn = document.getElementById('btn');

btn.addEventListener('click',(e)=>{
	// console.log('hello');
	location.href='<%=request.getContextPath() %>/';
	
});